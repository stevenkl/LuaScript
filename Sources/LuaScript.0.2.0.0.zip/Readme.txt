
LuaScript v0.2.0.0
                    2012/02/22
------------------------------



* Install
	> regsvr32 %YourPath%\LuaScript.dll



* Usage
	> cscript test.lua
	> cscript test.wsf
	@ http://host.domain/test.asp



* Note
	* LuaJIT(2.0.0 b9) is built-in as Lua Engine.



---
Natural Style Co. Ltd.
http://na-s.jp/



